package com.course.courseManagement.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.course.courseManagement.entity.Courses;

@Repository
public class CourseDao {
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    //*****************course Insertion*******************
    public boolean insertCourse(Courses course) {
        boolean status = false;
        try {
            String INSERT_COURSE_SQL = "INSERT INTO courses (id, name, description, duration, price) VALUES (?, ?, ?, ?, ?)";
            int count = jdbcTemplate.update(INSERT_COURSE_SQL, 
                course.getId(),
                course.getName(),
                course.getDescription(),
                course.getDuration(),
                course.getPrice());
            
            if(count > 0) {
                status = true;
            } else {
                status = false;
            }
        } catch(Exception e) {
            status = false;
            e.printStackTrace();
        }
        return status;
    }

    //***********************Course Updation*********************
    public boolean updateCourseById(Courses course) {
        boolean status = false;
        try {
            String UPDATE_COURSE_SQL = "UPDATE courses SET name = ?, description = ?, duration = ?, price = ? WHERE id = ?";
            int count = jdbcTemplate.update(UPDATE_COURSE_SQL, 
                course.getName(),
                course.getDescription(),
                course.getDuration(),
                course.getPrice(),
                course.getId());
            
            if(count > 0) {
                status = true;
            } else {
                status = false;
            }
        } catch (Exception e) {
            status = false;
            e.printStackTrace();
        }
        return status;
    }
        //***********************Course Deletion*********************
        public boolean deleteCourseById(int id){
            boolean status = false;
            try {
                String DELETE_COURSE_SQL = "DELETE FROM courses WHERE id = ?";
                int count = jdbcTemplate.update(DELETE_COURSE_SQL,id);
                if(count > 0) {
                    status = true;
                } else {
                    status = false;
                }
            } catch (Exception e) {
                status = false;
                e.printStackTrace();
            }
            return status;
            
            
            
            
            
            }
    }
}
