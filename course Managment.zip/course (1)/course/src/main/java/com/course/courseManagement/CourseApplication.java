package com.course.courseManagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.course.courseManagement.dao.CourseDao;
import com.course.courseManagement.entity.Courses;

@SpringBootApplication
public class CourseApplication implements CommandLineRunner {

    @Autowired
    private CourseDao coursedao;

    public static void main(String[] args) {
        SpringApplication.run(CourseApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
////        Courses course1 = new Courses(1, "Java Programming for Beginners", 
////                "A comprehensive course for beginners\n to learn Java programming\n from scratch.",
////                "3 months", 299.99);
//       // Courses course2 = new Courses(2, "Advanced Java Concepts", 
//                "Dive deep into advanced Java concepts\n like multithreading, collections,\n and design patterns.",
//                "4 months", 399.99);
//
////
//        // Call the method using the injected coursedao instance
//        boolean status = coursedao.insertCourse(course2);
//
//        if (status) {
//            System.out.println("Course inserted successfully!!");
//        } else {
//            System.out.println("Error inserting the course!");
//        }
    	
    	
    	
    /* //Updation Caller
    	// Create a course object to update an existing course (e.g., with id 1)
        Courses course = new Courses(1, "DSA Course", "Efficient Problem Solving Techniques", "4 months", 299.99);

        // Call the method to update the course in the database
        boolean status = coursedao.updateCourseById(course);

        if (status) {
            System.out.println("Course Updated Successfully!!");
        } else {
            System.out.println("Course update failed!!");
        }
        */
    	
    	
    	
    	//deletion caller
    	boolean status = coursedao.deleteCourseById(2);
    	
    	if (status) {
            System.out.println("Course deleted Successfully!!");
        } else {
            System.out.println("Course deletion failed!!");
        }
    }
    
 
    
    
}
